**A simple library to use Arithmetic Operations on Decimal**
- Addition, Subtraction, Multiplication, Division, Absolute, Factorial, Power, Square root, Modulus, LCM, GCD, Prime number, Even number, Odd number

**A Simple Library to use Arithmetic Operations on Binary**
- Addition, Subtraction, Multiplication, Division, Modulus, Power, AND, OR, XOR, NOT, Left Shift, Right Shift, 2's Complement, 1's Complement, 